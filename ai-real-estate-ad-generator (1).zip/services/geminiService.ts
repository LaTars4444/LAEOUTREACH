
import { GoogleGenAI } from '@google/genai';
import type { PropertyDetails } from '../types';

function constructAdPrompt(details: PropertyDetails): string {
  return `
    You are a professional real estate copywriter. Your task is to generate a compelling, persuasive, and enticing real estate advertisement for the following property.

    **Instructions:**
    1.  Start with a captivating headline.
    2.  Write a descriptive body that paints a picture for the potential buyer.
    3.  Highlight the key features provided.
    4.  Mention the number of bedrooms and bathrooms.
    5.  Include the price in a natural way.
    6.  End with a strong call to action, encouraging potential buyers to schedule a viewing.
    7.  The tone should be professional, warm, and inviting.
    8.  Format the output using markdown for better readability (e.g., headings, bold text, bullet points for features).

    **Property Details:**
    -   **Address:** ${details.address}
    -   **Asking Price:** ${details.price}
    -   **Bedrooms:** ${details.bedrooms}
    -   **Bathrooms:** ${details.bathrooms}
    -   **Key Features:** ${details.features}

    Now, generate the advertisement.
  `;
}

export const generateAd = async (details: PropertyDetails, apiKey: string): Promise<string> => {
  if (!apiKey) {
    return "An error occurred: The API Key is missing. Please provide it to continue.";
  }
  try {
    const ai = new GoogleGenAI({ apiKey: apiKey, vertexai: true });
    const prompt = constructAdPrompt(details);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        role: 'user',
        parts: [{ text: prompt }],
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("The AI returned an empty response.");
    }
    return text;
  } catch (error) {
    console.error("Error generating ad with Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            return 'An error occurred: The provided API Key is not valid. Please check the key and try again.';
        }
        return `An error occurred while generating the ad: ${error.message}. Please check the console for more details.`;
    }
    return "An unknown error occurred while generating the ad.";
  }
};

export const generateImage = async (details: PropertyDetails, apiKey: string): Promise<string> => {
  if (!apiKey) {
    return "An error occurred: The API Key is missing. Please provide it to continue.";
  }
  try {
    const ai = new GoogleGenAI({ apiKey: apiKey, vertexai: true });
    const prompt = `A stunning, photorealistic, professional real estate photograph of the exterior of a property.
    Property features: ${details.features}.
    The property is located at ${details.address}.
    The style should be bright, airy, and luxurious, suitable for a high-end real estate listing.
    It's a beautiful sunny day with a few wispy clouds in a clear blue sky.
    The image should be captured with a wide-angle lens to give a sense of space.
    Aspect ratio: 16:9.`;

    const response = await ai.models.generateImages({
        model: 'imagen-4.0-generate-001',
        prompt: prompt,
        config: {
          numberOfImages: 1,
          outputMimeType: 'image/jpeg',
          aspectRatio: '16:9',
        },
    });

    const base64ImageBytes: string | undefined = response.generatedImages?.[0]?.image?.imageBytes;
    if (!base64ImageBytes) {
      throw new Error("The AI did not return an image. The response might have been blocked due to safety policies.");
    }
    return base64ImageBytes;

  } catch (error) {
    console.error("Error generating image with Gemini API:", error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid')) {
            return 'An error occurred: The provided API Key is not valid. Please check the key and try again.';
        }
        return `An error occurred while generating the image: ${error.message}. Please check the console for more details.`;
    }
    return "An unknown error occurred while generating the image.";
  }
};
