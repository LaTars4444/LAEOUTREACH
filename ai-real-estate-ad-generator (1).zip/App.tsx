
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import RealEstateForm from './components/RealEstateForm';
import AdResult from './components/AdResult';
import ImageResult from './components/ImageResult';
import { generateAd, generateImage } from './services/apiService';
import type { PropertyDetails } from './types';

const App: React.FC = () => {
  const [adContent, setAdContent] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');
  
  const [imageUrl, setImageUrl] = useState<string>('');
  const [isImageLoading, setIsImageLoading] = useState<boolean>(false);
  const [imageError, setImageError] = useState<string>('');

  const handleGenerateAd = useCallback(async (details: PropertyDetails) => {
    setIsLoading(true);
    setError('');
    setAdContent('');
    
    const result = await generateAd(details);
    if (result.error) {
        setError(result.error);
    } else {
        setAdContent(result.content || '');
    }
    
    setIsLoading(false);
  }, []);

  const handleGenerateImage = useCallback(async (details: PropertyDetails) => {
    setIsImageLoading(true);
    setImageError('');
    setImageUrl('');
    
    const result = await generateImage(details);
    if (result.error) {
        setImageError(result.error);
    } else if (result.image_b64) {
        setImageUrl(`data:image/jpeg;base64,${result.image_b64}`);
    }
    
    setIsImageLoading(false);
  }, []);

  return (
    <div className="bg-slate-900 min-h-screen text-slate-100 font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 bg-slate-800/50 p-8 rounded-2xl shadow-lg border border-slate-700 self-start">
            <RealEstateForm 
              onGenerateAd={handleGenerateAd} 
              isAdLoading={isLoading}
              onGenerateImage={handleGenerateImage}
              isImageLoading={isImageLoading}
            />
          </div>
          <div className="lg:col-span-3 space-y-8">
             <div className="bg-slate-800/50 p-8 rounded-2xl shadow-lg border border-slate-700">
                <ImageResult imageUrl={imageUrl} isLoading={isImageLoading} error={imageError} />
             </div>
             <div className="bg-slate-800/50 p-8 rounded-2xl shadow-lg border border-slate-700">
                <AdResult content={adContent} isLoading={isLoading} error={error} />
             </div>
          </div>
        </div>
      </main>
      <footer className="text-center py-6 text-slate-500 text-sm">
        <p>Powered by TITAN AI. Created by Vertex AI Studio.</p>
      </footer>
    </div>
  );
};

export default App;
]]>
    </content>
  