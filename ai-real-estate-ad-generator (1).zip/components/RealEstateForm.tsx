
import React, { useState } from 'react';
import type { PropertyDetails } from '../types';
import { SparklesIcon } from './icons/SparklesIcon';
import { ImageIcon } from './icons/ImageIcon';

interface RealEstateFormProps {
  onGenerateAd: (details: PropertyDetails) => void;
  isAdLoading: boolean;
  onGenerateImage: (details: PropertyDetails) => void;
  isImageLoading: boolean;
}

const RealEstateForm: React.FC<RealEstateFormProps> = ({ onGenerateAd, isAdLoading, onGenerateImage, isImageLoading }) => {
  const [details, setDetails] = useState<PropertyDetails>({
    address: '123 Ocean View Drive, Malibu, CA',
    price: '$3,500,000',
    bedrooms: '4',
    bathrooms: '3.5',
    features: 'Stunning ocean views, infinity pool, gourmet kitchen, home theater, 3-car garage.',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setDetails(prev => ({ ...prev, [name]: value }));
  };

  const handleAdSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerateAd(details);
  };

  const handleImageClick = () => {
    onGenerateImage(details);
  };

  const isFormIncomplete = Object.values(details).some(value => value.trim() === '');
  const isLoading = isAdLoading || isImageLoading;

  return (
    <form onSubmit={handleAdSubmit} className="space-y-6">
      <h2 className="text-2xl font-semibold text-cyan-300 mb-4">Property Details</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="address" className="block text-sm font-medium text-slate-300 mb-1">Property Address</label>
          <input
            type="text"
            name="address"
            id="address"
            value={details.address}
            onChange={handleChange}
            placeholder="e.g., 123 Main St, Anytown, USA"
            className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            required
          />
        </div>
        <div>
          <label htmlFor="price" className="block text-sm font-medium text-slate-300 mb-1">Asking Price</label>
          <input
            type="text"
            name="price"
            id="price"
            value={details.price}
            onChange={handleChange}
            placeholder="e.g., $500,000"
            className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            required
          />
        </div>
        <div>
          <label htmlFor="bedrooms" className="block text-sm font-medium text-slate-300 mb-1">Bedrooms</label>
          <input
            type="number"
            name="bedrooms"
            id="bedrooms"
            min="0"
            value={details.bedrooms}
            onChange={handleChange}
            placeholder="e.g., 3"
            className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            required
          />
        </div>
        <div>
          <label htmlFor="bathrooms" className="block text-sm font-medium text-slate-300 mb-1">Bathrooms</label>
          <input
            type="number"
            name="bathrooms"
            id="bathrooms"
            min="0"
            step="0.5"
            value={details.bathrooms}
            onChange={handleChange}
            placeholder="e.g., 2.5"
            className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            required
          />
        </div>
      </div>

      <div>
        <label htmlFor="features" className="block text-sm font-medium text-slate-300 mb-1">Key Features</label>
        <textarea
          name="features"
          id="features"
          rows={4}
          value={details.features}
          onChange={handleChange}
          placeholder="e.g., Newly renovated kitchen, large backyard, ocean view, close to schools..."
          className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
          required
        />
      </div>

      <div className="space-y-3 pt-2">
        <button
          type="submit"
          disabled={isLoading || isFormIncomplete}
          className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
        >
          {isAdLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating Ad...
            </>
          ) : (
            <>
              <SparklesIcon className="w-5 h-5" />
              Generate Ad
            </>
          )}
        </button>
        <button
          type="button"
          onClick={handleImageClick}
          disabled={isLoading || isFormIncomplete}
          className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-purple-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
        >
          {isImageLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Generating Image...
            </>
          ) : (
            <>
              <ImageIcon className="w-5 h-5" />
              Generate Image
            </>
          )}
        </button>
      </div>
    </form>
  );
};

export default RealEstateForm;
