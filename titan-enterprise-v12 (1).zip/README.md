# Titan Enterprise V12.0.0 🏭

**Industrial-Grade Real Estate Acquisition Platform**

Titan Enterprise is a high-volume lead generation and outreach system designed for real estate investors. It features a "Self-Healing" architecture simulation, stealth scraping logic, and an automated outreach machine.

![Titan Enterprise](https://picsum.photos/800/400)

## 🚀 Features

*   **Lead Hunter:** Simulated high-volume scraper with stealth jitter protocols.
*   **Buy Box Logic:** Define automated acquisition criteria (Location, Price, Strategy).
*   **Campaign Machine:** Automated email outreach with variable injection (`[[ADDRESS]]`, `[[NAME]]`).
*   **Seller Portal:** Public-facing form for property owners to submit deals directly.
*   **Industrial Dashboard:** Real-time metrics, pipeline velocity, and terminal logs.

---

## ⚠️ Important: Architecture & Email Disclaimer

**Current Mode: Frontend Simulation**

This repository contains the **React Frontend** of the Titan Enterprise system.

1.  **Email Sending:** For security reasons, web browsers cannot send emails directly via SMTP (Gmail).
    *   The "Send" button in this app **simulates** the sending process (logs success, updates database state).
    *   **To send real emails:** You must connect this frontend to a backend API (Python/Flask or Node.js) that handles the SMTP handshake.
2.  **Data Persistence:** Data is currently persisted to `localStorage` to simulate a database. Clearing your browser cache will reset the app.

---

## 🛠️ Gmail Configuration (For Future Backend)

When you connect the backend, you **cannot** use your standard Gmail password. You must use an **App Password**.

1.  Go to your [Google Account Security Settings](https://myaccount.google.com/security).
2.  Enable **2-Step Verification**.
3.  Search for **"App Passwords"**.
4.  Create a new app password named "Titan Enterprise".
5.  Use that 16-character code in the Settings panel.

---

## ☁️ Deployment Guide (Render.com)

This application is optimized for **Render Static Sites**.

### Step 1: Upload to GitHub
1.  Initialize a repository: `git init`
2.  Add files: `git add .`
3.  Commit: `git commit -m "Initial Industrial Build"`
4.  Push to your GitHub repository.

### Step 2: Deploy on Render
1.  Log in to [Render.com](https://render.com).
2.  Click **New +** -> **Static Site**.
3.  Connect your GitHub repository.
4.  Use the following settings:
    *   **Name:** `titan-enterprise`
    *   **Branch:** `main` (or `master`)
    *   **Build Command:** `npm run build`
    *   **Publish Directory:** `dist`
5.  Click **Create Static Site**.

Your app will be live in minutes!

---

## 💻 Local Development

```bash
# Install dependencies
npm install

# Start the development server
npm start
```

## 🔒 Security

*   **Auth:** Simulated Scrypt hashing.
*   **Logs:** Immutable terminal logging for audit trails.
*   **Access:** Role-based routing (Operator vs. Public Seller).

---

*Titan Enterprise V12.0.0 - Industrial Standard*
