
import React from 'react';
import { ImageIcon } from './icons/ImageIcon';

interface ImageResultProps {
  imageUrl: string;
  isLoading: boolean;
  error: string;
}

const LoadingSkeleton: React.FC = () => (
  <div className="w-full aspect-video bg-slate-700 rounded-lg animate-pulse"></div>
);

const InitialState: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 min-h-[200px]">
        <ImageIcon className="w-16 h-16 mb-4 text-slate-600" />
        <h3 className="text-xl font-semibold text-slate-400">Generated Image Will Appear Here</h3>
        <p className="mt-2 max-w-sm">Click "Generate Image" to create a visual for your property.</p>
    </div>
);

const ImageResult: React.FC<ImageResultProps> = ({ imageUrl, isLoading, error }) => {
  return (
    <div className="h-full flex flex-col">
      <h2 className="text-2xl font-semibold text-purple-300 mb-4 flex-shrink-0">Generated Image</h2>
      <div className="flex-grow flex items-center justify-center">
        {isLoading && <LoadingSkeleton />}
        {error && <div className="text-red-400 bg-red-900/50 p-4 rounded-md w-full">{error}</div>}
        {!isLoading && !error && imageUrl && (
          <img src={imageUrl} alt="Generated real estate property" className="rounded-lg shadow-lg object-cover w-full" />
        )}
        {!isLoading && !error && !imageUrl && <InitialState />}
      </div>
    </div>
  );
};

export default ImageResult;
