
import os
import json
import sqlite3
import secrets
import logging
import base64
import uuid
from datetime import datetime, timedelta

import stripe
from flask import Flask, render_template, request, redirect, url_for, session, flash, Response, jsonify, send_from_directory
from cryptography.fernet import Fernet
from groq import Groq

# Google Auth Imports (assuming they are installed)
# from google_auth_oauthlib.flow import Flow
# from google.oauth2 import id_token
# from google.auth.transport import requests as google_requests
# from googleapiclient.discovery import build
# from email.mime.text import MIMEText

# ==========================================
# CONFIG & INITIALIZATION
# ==========================================
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("TITAN_CORE")

app = Flask(__name__, static_folder='static', template_folder='static')
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(64))

# This key should be the same as the one used for existing data
ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY")
if not ENCRYPTION_KEY:
    raise ValueError("ENCRYPTION_KEY environment variable not set!")
cipher = Fernet(ENCRYPTION_KEY.encode())

stripe.api_key = os.environ.get("STRIPE_SECRET_KEY")
groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))

# Render Persistence: SQLite must be in a mounted disk directory
DB_PATH = os.path.join(os.environ.get("RENDER_DISK_PATH", "."), "titan_main_v28.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

PRICE_IDS = {
    'EMAIL_MACHINE_LIFETIME': "price_1Spy7SFXcDZgM3VoVZv71I63",
    'EMAIL_MACHINE_WEEKLY': "price_1SpxexFXcDZgM3Vo0iYmhfpb",
    'NEURAL_AGENT_MONTHLY': "price_1SqIjgFXcDZgM3VoEwrUvjWP"
}

# NOTE: Google Auth parts are commented out as they are not used by the React UI,
# but the logic is kept for other parts of the TITAN application.
# GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID")
# REDIRECT_URI = os.environ.get("REDIRECT_URI")
# SCOPES = ['https://www.googleapis.com/auth/userinfo.email', 'openid', 'https://www.googleapis.com/auth/gmail.send']

# ==========================================
# DATABASE LAYER (as provided)
# ==========================================
class TitanDatabase:
    def __init__(self, path):
        self.path = path
        self._init_tables()

    def get_connection(self):
        conn = sqlite3.connect(self.path, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    def _init_tables(self):
        with self.get_connection() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS users (
                email TEXT PRIMARY KEY, full_name TEXT, profile_pic TEXT,
                email_machine_access INTEGER DEFAULT 0, email_trial_end TEXT, email_trial_used INTEGER DEFAULT 0,
                ai_access INTEGER DEFAULT 0, ai_trial_end TEXT, ai_trial_used INTEGER DEFAULT 0,
                google_creds_enc TEXT, last_login TEXT, created_at TEXT
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS leads (
                id INTEGER PRIMARY KEY AUTOINCREMENT, address TEXT, asking_price INTEGER, 
                arv INTEGER, seller_email TEXT, created_at TEXT
            )""")
            conn.commit()

    def get_user(self, email):
        with self.get_connection() as conn:
            return conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()

db = TitanDatabase(DB_PATH)

# ==========================================
# ACCESS & AUTH LOGIC (as provided)
# ==========================================
class TitanAccess:
    @staticmethod
    def check(user, product_type):
        if not user:
            return False
        now = datetime.now()
        if product_type == "email":
            if user['email_machine_access']: return True
            if user['email_trial_end'] and now < datetime.fromisoformat(user['email_trial_end']): return True
        if product_type == "ai":
            if user['ai_access']: return True
            if user['ai_trial_end'] and now < datetime.fromisoformat(user['ai_trial_end']): return True
        return False

# ==========================================
# AI GENERATION API ROUTES
# ==========================================
@app.route('/api/generate-ad', methods=['POST'])
def api_generate_ad():
    # Faking user session for demonstration. In production, this comes from your real auth flow.
    # session['user_email'] = 'test-user@example.com' 
    if 'user_email' not in session:
        return jsonify({"error": "Authentication required."}), 401
    
    user = db.get_user(session['user_email'])
    if not TitanAccess.check(user, "ai"):
        return jsonify({"error": "Access denied. Please subscribe to the AI Marketing Tool."}), 403

    details = request.json
    if not all(k in details for k in ['address', 'price', 'bedrooms', 'bathrooms', 'features']):
        return jsonify({"error": "Missing property details."}), 400

    prompt = f"""
    You are a professional real estate copywriter. Your task is to generate a compelling, persuasive, and enticing real estate advertisement for the following property.

    **Instructions:**
    1.  Start with a captivating headline.
    2.  Write a descriptive body that paints a picture for the potential buyer.
    3.  Highlight the key features provided.
    4.  Mention the number of bedrooms and bathrooms.
    5.  Include the price in a natural way.
    6.  End with a strong call to action, encouraging potential buyers to schedule a viewing.
    7.  The tone should be professional, warm, and inviting.
    8.  Format the output using markdown for better readability (e.g., headings, bold text, bullet points for features).

    **Property Details:**
    -   **Address:** {details['address']}
    -   **Asking Price:** {details['price']}
    -   **Bedrooms:** {details['bedrooms']}
    -   **Bathrooms:** {details['bathrooms']}
    -   **Key Features:** {details['features']}

    Now, generate the advertisement.
    """
    try:
        res = groq_client.chat.completions.create(messages=[{"role": "user", "content": prompt}], model="llama3-70b-8192")
        content = res.choices[0].message.content
        return jsonify({"content": content})
    except Exception as e:
        logger.error(f"Groq API error: {e}")
        return jsonify({"error": "Failed to generate ad due to an internal error."}), 500

@app.route('/api/generate-image', methods=['POST'])
def api_generate_image():
    # This is a placeholder as Groq does not support image generation.
    # To implement this, you would need a different service like Gemini/Imagen.
    # For now, it returns a placeholder image to make the UI functional.
    if 'user_email' not in session:
        return jsonify({"error": "Authentication required."}), 401
    
    user = db.get_user(session['user_email'])
    if not TitanAccess.check(user, "ai"):
        return jsonify({"error": "Access denied. Please subscribe to the AI Marketing Tool."}), 403

    # Placeholder image logic
    # In a real scenario with an image model, you would call it here.
    # For example: image_bytes = call_imagen_api(details)
    # For now, we read a placeholder from disk.
    try:
        # This is a simple placeholder. You can replace this with a call to a real image generation API.
        # The placeholder image is a 1x1 red pixel.
        placeholder_base64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/wcAAwAB/epv2AAAAABJRU5ErkJggg=="
        return jsonify({"image_b64": placeholder_base64})
    except Exception as e:
        logger.error(f"Image generation placeholder error: {e}")
        return jsonify({"error": "Failed to generate image due to an internal error."}), 500

# ==========================================
# REACT FRONTEND SERVING
# ==========================================
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_react_app(path):
    # This route should be protected by your login logic.
    # If 'user_email' not in session, redirect to '/auth/login'
    # For now, we allow access to demonstrate the UI.
    # if 'user_email' not in session:
    #     return redirect(url_for('login')) # Assuming 'login' is your Google OAuth route
    
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        # The template should point to the built React JS file.
        return render_template("index.html")

# Add your existing auth and webhook routes here...
# @app.route('/auth/login') ...
# @app.route('/callback') ...
# @app.route('/webhook') ...

if __name__ == '__main__':
    # This is for local development, not for Render.
    # On Render, Gunicorn will be used.
    app.run(host='0.0.0.0', port=5000, debug=True)
]]>
    </content>
  