
export interface PropertyDetails {
  address: string;
  price: string;
  bedrooms: string;
  bathrooms: string;
  features: string;
}
