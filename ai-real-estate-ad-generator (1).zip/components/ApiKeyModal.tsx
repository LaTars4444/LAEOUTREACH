
import React, { useState } from 'react';
import { KeyIcon } from './icons/KeyIcon';

interface ApiKeyModalProps {
  onSave: (key: string) => void;
}

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ onSave }) => {
  const [key, setKey] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (key.trim()) {
      onSave(key.trim());
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-90 backdrop-blur-sm flex items-center justify-center z-50">
      <form onSubmit={handleSave} className="bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl p-8 max-w-lg w-full m-4">
        <div className="flex items-center gap-3 mb-4">
            <KeyIcon className="w-8 h-8 text-yellow-400" />
            <h2 className="text-2xl font-bold text-white">Enter Your Gemini API Key</h2>
        </div>
        <p className="text-slate-400 mb-6">
          To use this application, you need a Google Gemini API key. You can get one for free from{' '}
          <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:underline">
            Google AI Studio
          </a>.
        </p>
        <div className="space-y-4">
          <input
            type="password"
            value={key}
            onChange={(e) => setKey(e.target.value)}
            placeholder="Enter your API key here"
            className="w-full bg-slate-700 border border-slate-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500"
            aria-label="Gemini API Key"
          />
          <button
            type="submit"
            disabled={!key.trim()}
            className="w-full flex justify-center items-center gap-2 py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-cyan-500 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors"
          >
            Save and Continue
          </button>
        </div>
        <p className="text-xs text-slate-500 mt-4 text-center">
          Your key is saved in your browser's local storage and is not sent anywhere except to Google's API.
        </p>
      </form>
    </div>
  );
};

export default ApiKeyModal;
