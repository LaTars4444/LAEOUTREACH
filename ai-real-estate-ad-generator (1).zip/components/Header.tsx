
import React from 'react';
import { PropertyIcon } from './icons/PropertyIcon';

const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/70 backdrop-blur-lg border-b border-slate-700 sticky top-0 z-20">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <PropertyIcon className="w-8 h-8 text-cyan-400" />
          <h1 className="text-2xl font-bold tracking-tight text-white">
            AI Real Estate Ad Generator
          </h1>
        </div>
        <a href="/auth/logout" className="text-slate-400 hover:text-white transition-colors">Logout</a>
      </div>
    </header>
  );
};

export default Header;
]]>
    </content>
  