
import React from 'react';
import { SparklesIcon } from './icons/SparklesIcon';

interface AdResultProps {
  content: string;
  isLoading: boolean;
  error: string;
}

const LoadingSkeleton: React.FC = () => (
  <div className="space-y-4 animate-pulse">
    <div className="h-6 bg-slate-700 rounded w-3/4"></div>
    <div className="space-y-2 pt-2">
      <div className="h-4 bg-slate-700 rounded"></div>
      <div className="h-4 bg-slate-700 rounded w-5/6"></div>
      <div className="h-4 bg-slate-700 rounded w-4/6"></div>
    </div>
    <div className="space-y-2 pt-4">
      <div className="h-4 bg-slate-700 rounded w-1/2"></div>
      <div className="h-4 bg-slate-700 rounded"></div>
      <div className="h-4 bg-slate-700 rounded w-5/6"></div>
    </div>
     <div className="space-y-2 pt-4">
      <div className="h-4 bg-slate-700 rounded w-1/3"></div>
    </div>
  </div>
);

const InitialState: React.FC = () => (
    <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 min-h-[150px]">
        <SparklesIcon className="w-16 h-16 mb-4 text-slate-600" />
        <h3 className="text-xl font-semibold text-slate-400">Your Generated Ad Will Appear Here</h3>
        <p className="mt-2 max-w-sm">Fill out the property details and click "Generate Ad" to create the marketing copy.</p>
    </div>
);

const AdResult: React.FC<AdResultProps> = ({ content, isLoading, error }) => {
  return (
    <div className="h-full flex flex-col">
      <h2 className="text-2xl font-semibold text-cyan-300 mb-4 flex-shrink-0">Generated Advertisement</h2>
      <div className="bg-slate-900/70 p-6 rounded-lg flex-grow overflow-y-auto border border-slate-700 min-h-[250px]">
        {isLoading && <LoadingSkeleton />}
        {error && (
            <div className="text-red-400 bg-red-900/50 p-4 rounded-md">
                <p className="font-bold mb-2">An Error Occurred</p>
                <p>{error}</p>
            </div>
        )}
        {!isLoading && !error && content && (
          <pre className="text-slate-300 whitespace-pre-wrap font-sans text-base leading-relaxed">
            {content}
          </pre>
        )}
        {!isLoading && !error && !content && <InitialState />}
      </div>
    </div>
  );
};

export default AdResult;
]]>
    </content>
  