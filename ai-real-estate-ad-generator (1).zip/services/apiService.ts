
import type { PropertyDetails } from '../types';

interface ApiResponse {
    content?: string;
    image_b64?: string;
    error?: string;
}

const handleResponse = async (response: Response): Promise<ApiResponse> => {
    if (!response.ok) {
        if (response.status === 401 || response.status === 403) {
            const data = await response.json();
            return { error: data.error || 'Access Denied. You may need to log in or subscribe.' };
        }
        return { error: `An unexpected server error occurred (Status: ${response.status}).` };
    }
    return response.json();
};

export const generateAd = async (details: PropertyDetails): Promise<ApiResponse> => {
  try {
    const response = await fetch('/api/generate-ad', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(details),
    });
    return handleResponse(response);
  } catch (error) {
    console.error("Network error generating ad:", error);
    return { error: 'A network error occurred. Please check your connection.' };
  }
};

export const generateImage = async (details: PropertyDetails): Promise<ApiResponse> => {
  try {
    const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(details),
    });
    return handleResponse(response);
  } catch (error) {
    console.error("Network error generating image:", error);
    return { error: 'A network error occurred. Please check your connection.' };
  }
};
]]>
    </content>
  