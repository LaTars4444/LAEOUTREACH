import os
import threading
from flask import Flask, jsonify, request
from flask_cors import CORS
from extensions import db, login_manager
from models import User, Lead, Investor, OutreachLog
from tasks import google_search_hunter
from werkzeug.security import generate_password_hash, check_password_hash

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'dev_key')
    # Use Render's DATABASE_URL if available, else sqlite
    database_url = os.environ.get('DATABASE_URL')
    if database_url and database_url.startswith("postgres://"):
        database_url = database_url.replace("postgres://", "postgresql://", 1)
    
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url or 'sqlite:///titan.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize Extensions
    db.init_app(app)
    login_manager.init_app(app)
    
    # Enable CORS for React Frontend
    CORS(app)

    with app.app_context():
        db.create_all()

    return app

app = create_app()

@app.route('/')
def health_check():
    return jsonify({"status": "Titan Enterprise API Online", "version": "12.0.0"})

# --- API ROUTES FOR REACT FRONTEND ---

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    user = User.query.filter_by(email=data.get('email')).first()
    if user and check_password_hash(user.password, data.get('password')):
        return jsonify({"message": "Login successful", "user_id": user.id, "api_key": user.groq_api_key})
    return jsonify({"error": "Invalid credentials"}), 401

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json
    if User.query.filter_by(email=data.get('email')).first():
        return jsonify({"error": "User exists"}), 400
    
    hashed = generate_password_hash(data.get('password'), method='scrypt')
    new_user = User(email=data.get('email'), password=hashed)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User created", "user_id": new_user.id})

@app.route('/api/leads/hunt', methods=['POST'])
def trigger_hunt():
    data = request.json
    api_key = os.environ.get('GOOGLE_SEARCH_API_KEY')
    cx = os.environ.get('GOOGLE_SEARCH_CX')
    
    if not api_key or not cx:
        return jsonify({"error": "Server missing Google Keys"}), 500

    # Run in background
    thread = threading.Thread(target=google_search_hunter, args=(app, data.get('user_id'), data.get('city'), data.get('state'), api_key, cx))
    thread.start()
    
    return jsonify({"message": "Hunt started in background"})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)
